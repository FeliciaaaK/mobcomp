//
//  polpal_feliTests.swift
//  polpal feliTests
//
//  Created by student on 04/12/25.
//

import Testing
@testable import polpal_feli

struct polpal_feliTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
