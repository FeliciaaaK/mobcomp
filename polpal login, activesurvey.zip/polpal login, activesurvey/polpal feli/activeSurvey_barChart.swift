//
//  activeSurvey_barChart.swift
//  polpal feli
//
//  Created by student on 04/12/25.
//

import Charts
import SwiftUI

struct activeSurvey_barChart: View {
    struct ChartItem {
        let label: String
        let value: Int
    }

    let chartData: [ChartItem] = [
        ChartItem(label: "Mie Gacoan", value: 90),
        ChartItem(label: "Udang Keju", value: 30),
    ]

    var body: some View {
        VStack(spacing: 0) {

            // MARK: - HEADER
            VStack(spacing: 12) {
                Text("Cooking Mama Survey")
                    .font(.title.bold())
                    .foregroundColor(.white)
            }
            .frame(maxWidth: .infinity)
            .frame(height: 130)
            .background(Color.orange)

            // MARK: - CARD UTAMA (container seluruh konten)
            ZStack {
                // Background card utama
                RoundedRectangle(cornerRadius: 40)
                    .fill(Color.white)
                    .shadow(color: .black.opacity(0.15), radius: 10, y: -2)

                VStack(spacing: 20) {

                    // ====== CARD PUTIH 1 ======
                    VStack(alignment: .leading, spacing: 12) {

                        Text("Suka gacoan ato dimsum?")
                            .font(.headline.bold())
                            .foregroundColor(Color(hex: "1F3A45"))

                        Text("100 responses")
                            .font(.subheadline.weight(.semibold))
                            .foregroundColor(Color(hex: "1F3A45"))

                        HStack {
                            Spacer()
                            Text("Short Answer")
                                .font(.footnote.bold())
                                .padding(.horizontal, 15)
                                .padding(.vertical, 8)
                                .background(Color.orange)
                                .foregroundColor(.white)
                                .cornerRadius(20)
                        }

                    }
                    .padding(20)
                    .frame(maxWidth: .infinity)
                    .background(Color.white)
                    .cornerRadius(30)
                    .shadow(color: .black.opacity(0.1), radius: 8, y: 4)
                    //                            .offset(y: -60)

                    // ====== CARD PUTIH 2 (SCROLL ONLY) ======
                    VStack {
                        ScrollView(showsIndicators: false) {

                            //                            VStack(alignment: .leading, spacing: 15) {

                            Text("Hasil Jawaban")
                                .font(.headline.bold())
                                .foregroundColor(Color(hex: "1F3A45"))

                            Chart {
                                ForEach(chartData, id: \.label) { item in
                                    BarMark(
                                        x: .value("Jumlah", item.value),
                                        y: .value("Jawaban", item.label)
                                    )
                                    .foregroundStyle(Color(hex: "1F3A45"))

                                }
                            }
                            .frame(height: 250)
                            //                            }
                            //                            .padding(30)
                            //                            .frame(maxWidth: .infinity)
                            //                            .background(Color.white)
                            //                            .cornerRadius(30)
                            //                            .shadow(color: .black.opacity(0.1), radius: 8, y: 4)

                        }
                    }
                    .padding(30)
                    .frame(maxWidth: .infinity, maxHeight: 430)
                    .background(Color.white)
                    .cornerRadius(30)
                    .shadow(color: .black.opacity(0.1), radius: 8, y: 4)

                    // ====== FOOTER BUTTONS (di dalam card utama) ======
                    HStack(spacing: 15) {
                        Button(action: {}) {
                            Text("Previous")
                                .font(.subheadline.bold())
                                .foregroundColor(.white)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.orange)
                                .cornerRadius(18)
                        }

                        Button(action: {}) {
                            Text("Next")
                                .font(.subheadline.bold())
                                .foregroundColor(.white)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.orange)
                                .cornerRadius(18)
                        }
                    }
                    .padding(.horizontal)
                    .padding(.bottom, 20)

                }
                .padding(.horizontal)
                .padding(.top, 10)

            }
            .offset(y: -40)  // Naik sedikit menutupi header
            .padding(.bottom, -70)  // Supaya card menjangkau bawah

        }
        .background(Color(hex: "1F3A45").opacity(0.05).ignoresSafeArea())
    }
}

#Preview {
    activeSurvey_barChart()
}
