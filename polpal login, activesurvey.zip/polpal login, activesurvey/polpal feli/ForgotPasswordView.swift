//
//  ForgotPasswordView.swift
//  polpal feli
//
//  Created by student on 04/12/25.
//

import SwiftUI

struct ForgotPasswordView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    ForgotPasswordView()
}
