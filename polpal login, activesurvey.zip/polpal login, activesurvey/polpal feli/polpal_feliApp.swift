//
//  polpal_feliApp.swift
//  polpal feli
//
//  Created by student on 04/12/25.
//

import SwiftUI

@main
struct polpal_feliApp: App {
    var body: some Scene {
        WindowGroup {
            VerifyCodeView()
        }
    }
}
