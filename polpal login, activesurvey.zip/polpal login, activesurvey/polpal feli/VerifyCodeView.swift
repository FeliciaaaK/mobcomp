//
//  VerifyCodeView.swift
//  polpal feli
//
//  Created by student on 04/12/25.
//

import SwiftUI
// MARK: - OTP Input Box Helper
struct OTPBoxView: View {
    var digit: String
    
    var body: some View {
        Text(digit)
            .font(.title2)
            .fontWeight(.bold)
            .frame(width: 60, height: 60)
            .background(Color.white)
            .cornerRadius(10)
            .overlay(
                RoundedRectangle(cornerRadius: 10)
                    .stroke(Color.darkTeal, lineWidth: 1)
            )
    }
}


struct VerifyCodeView: View {
    @State private var code: String = ""
    @FocusState private var isFocused: Bool

    let maxDigits = 4

    var body: some View {
        ZStack {
            Color.white.edgesIgnoringSafeArea(.all)

            VStack(alignment: .leading, spacing: 50) {

                // MARK: Header
                VStack(alignment: .leading, spacing: 8) {
                    Text("Verify Code")
                        .font(.system(size: 32, weight: .bold))
                        .foregroundColor(Color.darkTeal)

                    Text("Please enter the email code")
                        .font(.body)
                        .foregroundColor(.gray)
                }

                // MARK: OTP Blocks
                VStack(spacing: 30) {

                    // TextField kecil tapi tetap aktif → keyboard muncul
                    TextField("", text: $code)
                        .keyboardType(.numberPad)
                        .focused($isFocused)
                        .frame(width: 0, height: 0)
                        .clipped()
                        .onChange(of: code) { oldValue, newValue in
                            if newValue.count > maxDigits {
                                code = String(newValue.prefix(maxDigits))
                            }
                        }

                    // Kotak OTP
                    HStack(spacing: 15) {
                        ForEach(0..<maxDigits, id: \.self) { index in
                            OTPBoxView(digit: getDigit(at: index))
                                .onTapGesture {
                                    isFocused = true       // keyboard should show
                                }
                        }
                    }
                }
                .onAppear {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                        isFocused = true   // auto focus working again
                    }
                }


                Spacer()

                // MARK: Verify Button
                Button(action: {
                    print("Verifying code: \(code)")
                }) {
                    Text("Verify")
                        .font(.system(size: 20, weight: .bold))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 18)
                        .background(
                            code.count == maxDigits
                                ? Color.darkTeal : Color.gray
                        )
                        .cornerRadius(18)
                }
                .disabled(code.count != maxDigits)
                .padding(.bottom, 20)
            }
            .padding(.horizontal, 30)
            .padding(.top, 50)
        }
    }

    // Helper to show each digit
    func getDigit(at index: Int) -> String {
        guard index < code.count else { return "" }
        let charIndex = code.index(code.startIndex, offsetBy: index)
        return String(code[charIndex])
    }
}

extension Color {
    static let darkTeal = Color(red: 12/255, green: 66/255, blue: 84/255)
    static let brandOrange = Color(red: 254/255, green: 152/255, blue: 42/255)
    static let inputGray = Color(red: 235/255, green: 235/255, blue: 235/255)
}

#Preview {
    VerifyCodeView()
}
