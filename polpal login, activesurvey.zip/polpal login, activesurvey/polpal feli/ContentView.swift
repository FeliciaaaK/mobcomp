//
//  ContentView.swift
//  polpal feli
//
//  Created by student on 04/12/25.
//

import SwiftUI

struct ContentView: View {
    let responses = Array(repeating: "Talitha Celin Soal matematika kali ini sangat sulit, bahkan untuk Raka. Dua soal terakhir membuatnya buntu. Keringat dingin mulai membasahi pelipisnya. Saat ia menghela napas, matanya tak sengaja menangkap gerakan dari bangku depan. Dinda, teman sebangkunya yang dikenal sering mendapat nilai pas-pasan, dengan cepat menyembunyikan secarik kertas kecil di bawah lengannya. Raka tahu itu adalah contekan.", count: 10)

    var body: some View {
        VStack(spacing: 0) {

            // MARK: - HEADER
            VStack(spacing: 12) {
                Text("Cooking Mama Survey")
                    .font(.title.bold())
                    .foregroundColor(.white)
            }
            .frame(maxWidth: .infinity)
            .frame(height: 130)
            .background(Color.orange)

            // MARK: - CARD UTAMA (container seluruh konten)
            ZStack {
                // Background card utama
                RoundedRectangle(cornerRadius: 40)
                    .fill(Color.white)
                    .shadow(color: .black.opacity(0.15), radius: 10, y: -2)

                VStack(spacing: 20) {

                    // ====== CARD PUTIH 1 ======
                    VStack(alignment: .leading, spacing: 12) {

                        Text("Nama Lengkap")
                            .font(.headline.bold())
                            .foregroundColor(Color(hex: "1F3A45"))

                        Text("100 responses")
                            .font(.subheadline.weight(.semibold))
                            .foregroundColor(Color(hex: "1F3A45"))

                        HStack {
                            Spacer()
                            Text("Short Answer")
                                .font(.footnote.bold())
                                .padding(.horizontal, 15)
                                .padding(.vertical, 8)
                                .background(Color.orange)
                                .foregroundColor(.white)
                                .cornerRadius(20)
                        }

                    }
                    .padding(20)
                    .frame(maxWidth: .infinity)
                    .background(Color.white)
                    .cornerRadius(30)
                    .shadow(color: .black.opacity(0.1), radius: 8, y: 4)
                    //                            .offset(y: -60)

                    // ====== CARD PUTIH 2 (SCROLL ONLY) ======
                    VStack {
                        ScrollView(showsIndicators: false) {
                            VStack(spacing: 12) {
                                ForEach(responses, id: \.self) { name in
                                    HStack {
                                        Text(name)
                                            .font(.headline)
                                            .foregroundColor(
                                                Color(hex: "1F3A45")
                                            )

                                        Spacer()
                                    }
                                    .padding()
                                    .frame(maxWidth: .infinity)
                                    .background(Color.orange.opacity(0.45))
                                    .cornerRadius(15)
                                }
                            }
                            .padding(.horizontal)
                            .padding(.vertical)  //ini
                            .padding(.bottom, 25)
                        }
                    }
                    .frame(maxWidth: .infinity, maxHeight: 430)
                    .background(Color.white)
                    .cornerRadius(30)
                    .shadow(color: .black.opacity(0.1), radius: 8, y: 4)

                    // ====== FOOTER BUTTONS (di dalam card utama) ======
                    HStack(spacing: 15) {
                        Button(action: {}) {
                            Text("Previous")
                                .font(.subheadline.bold())
                                .foregroundColor(.white)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.orange)
                                .cornerRadius(18)
                        }

                        Button(action: {}) {
                            Text("Next")
                                .font(.subheadline.bold())
                                .foregroundColor(.white)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.orange)
                                .cornerRadius(18)
                        }
                    }
                    .padding(.horizontal)
                    .padding(.bottom, 20)

                }
                .padding(.horizontal)
                .padding(.top, 10)

            }
            .offset(y: -40)  // Naik sedikit menutupi header
            .padding(.bottom, -70)  // Supaya card menjangkau bawah

        }
        .background(Color(hex: "1F3A45").opacity(0.05).ignoresSafeArea())
    }
}

//MARK: - Hex Color Extension
extension Color {
    init(hex: String) {
        let scanner = Scanner(string: hex)
        scanner.currentIndex = hex.startIndex
        var rgbValue: UInt64 = 0
        scanner.scanHexInt64(&rgbValue)

        let r = Double((rgbValue >> 16) & 0xFF) / 255.0
        let g = Double((rgbValue >> 8) & 0xFF) / 255.0
        let b = Double(rgbValue & 0xFF) / 255.0

        self.init(red: r, green: g, blue: b)
    }
}

#Preview {
    ContentView()
}
