//
//  PolPal_FeliTests.swift
//  PolPal_FeliTests
//
//  Created by student on 27/11/25.
//

import Testing
@testable import PolPal_Feli

struct PolPal_FeliTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
