//
//  PolPal_FeliApp.swift
//  PolPal_Feli
//
//  Created by student on 27/11/25.
//

import SwiftUI

@main
struct PolPal_FeliApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
